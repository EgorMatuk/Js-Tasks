// switch case
/* var test = '';

switch('Hello'){
    case 'Hello' : 
        console.log('Hello');
        test = 'Hello';
    break;
    case 'Hello!!!' :
        console.log('1267867812');
        test = '1267867812';
        break;
    default : 
        console.log('Default info')
        test = 'Default info';
    break;
}
 */
//console.log('Test равна: ' + test);

var iterator = 0;
/* console.log(++iterator)
console.log(++iterator)
console.log(++iterator)
console.log(++iterator)
console.log(++iterator)
 */
/* for(; ;  ){
    console.log(i);
} */

/* while(1){

} */



/* var num1 = 10;
var num2 = 20;
var num3 = 30;
console.log(num1+num2+num3);

var num4 = 1;
var num5 = 2;
var num6 = 3;
console.log(num4+num5+num6) */


function sum(par1, par2, par3){
    /* var par1 = 10;
    var par2 = 20;
    var par3 = 30; */
    //console.log(par1+par2+par3);
    return par1+par2+par3;
}

var result1 = sum(1,2,3);
console.log(result1);

/* sum(1,2,3);
sum(1.2321, -19, 188);
sum(929, 72727, 19189) */