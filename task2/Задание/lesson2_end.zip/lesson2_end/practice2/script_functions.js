//1.Напишите функцию max(a,b), которая возвращает наибольшее из чисел a и b.

function max(a,b){
    if(a > b){
        console.log(a);
    }else{
       console.log(b); 
    }
}

/* max(10, 7); */





//2.Написать функцию, которая вычисляет среднее арифметическое элементов , переданных ей в качестве аргументов. Пусть будет передано 3 аргумента.


function average(par1, par2, par3){
    var sum = par1 + par2 + par3;
    console.log(sum/3);
}
 
/* average(2, 4, 6);
average(2.12, 4.134, 6.52); */




//3.Напишите функцию pow(x,n), которая возвращает x в степени n. Иначе говоря, умножает x на себя n раз и возвращает результат.


function pow(x, n){
    /* var result = Math.pow(x, n);
    return result; */
    let result = 1;
    for(var i =0; i < n; i++ ){
        result *= x;
    }
    return result;
} 

console.log(pow(2, 3))
console.log(pow(2, 10))